//
//  OpenplatformSDK.h
//  OpenplatformSDK
//
//  Created by giordano scalzo on 14/11/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for OpenplatformSDK.
FOUNDATION_EXPORT double OpenplatformSDKVersionNumber;

//! Project version string for OpenplatformSDK.
FOUNDATION_EXPORT const unsigned char OpenplatformSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OpenplatformSDK/PublicHeader.h>
